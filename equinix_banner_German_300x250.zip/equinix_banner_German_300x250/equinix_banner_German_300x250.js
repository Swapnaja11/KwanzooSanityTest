(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.beam1 = function() {
	this.initialize(img.beam1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,191,162);


(lib.beam2 = function() {
	this.initialize(img.beam2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,109,42);


(lib.cta_glow = function() {
	this.initialize(img.cta_glow);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,100,35);


(lib.img35_85p = function() {
	this.initialize(img.img35_85p);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,439,303);


(lib.img35Grey = function() {
	this.initialize(img.img35Grey);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.nod = function() {
	this.initialize(img.nod);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,29,29);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txtEnd = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAhBGIg8hMIAABMIgmAAIAAiLIAkAAIA4BJIAAhJIAnAAIAACLg");
	this.shape.setTransform(248.5,89);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag1AzQgVgUAAgfIAAAAQAAgeAVgUQAWgWAfAAQAgAAAWAWQAVAUAAAeIAAAAQAAAfgVAUQgWAWggAAQgfAAgWgWgAgZgaQgKALAAAPIAAAAQAAAQAKAKQAKAMAPAAQAQAAAKgMQAKgKAAgQIAAAAQAAgOgKgMQgLgLgPAAQgPAAgKALg");
	this.shape_1.setTransform(232.3,89);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgSBGIAAiLIAlAAIAACLg");
	this.shape_2.setTransform(220.8,89);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgTBGIAAhpIgpAAIAAgiIB5AAIAAAiIgqAAIAABpg");
	this.shape_3.setTransform(210.9,89);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgtA0QgVgUAAggIAAAAQAAgeAUgUQAWgWAeAAQAnAAAVAdIgdAXQgOgRgRAAQgNABgKAKQgKALABAPIAAAAQgBAQAKAKQAKAMANAAQASAAAOgRIAdAUQgXAggnAAQgeAAgUgVg");
	this.shape_4.setTransform(197.2,89);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag4BGIAAiLIBwAAIAAAhIhJAAIAAAVIBCAAIAAAeIhCAAIAAAWIBKAAIAAAhg");
	this.shape_5.setTransform(183.3,89);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAgBGIg6hMIAABMIgnAAIAAiLIAkAAIA5BJIAAhJIAmAAIAACLg");
	this.shape_6.setTransform(168.5,89);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAhBGIg8hMIAABMIgmAAIAAiLIAkAAIA4BJIAAhJIAnAAIAACLg");
	this.shape_7.setTransform(152.8,89);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag1AzQgVgUAAgfIAAAAQAAgeAVgUQAWgWAfAAQAgAAAWAWQAVAUAAAeIAAAAQAAAfgVAUQgWAWggAAQgfAAgWgWgAgZgaQgKALAAAPIAAAAQAAAQAKAKQAKAMAPAAQAQAAAKgMQAKgKAAgQIAAAAQAAgOgKgMQgLgLgPAAQgPAAgKALg");
	this.shape_8.setTransform(136.7,89);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgtA0QgVgUAAggIAAAAQAAgeAVgUQAVgWAeAAQAmAAAWAdIgdAXQgOgRgRAAQgNABgKAKQgJALAAAPIAAAAQAAAQAJAKQAKAMANAAQARAAAPgRIAdAUQgXAggnAAQgdAAgVgVg");
	this.shape_9.setTransform(121.3,89);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAUBGIgbgrIgSAAIAAArIgmAAIAAiLIBBAAQAeAAAPAPQANAMAAAVIAAAAQAAAegdAMIAhAxgAgZgCIAZAAQAKAAAGgEQAFgEAAgJIAAAAQAAgRgVAAIgZAAg");
	this.shape_10.setTransform(107.1,89);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("Ag4BGIAAiLIBwAAIAAAhIhJAAIAAAVIBCAAIAAAeIhCAAIAAAWIBKAAIAAAhg");
	this.shape_11.setTransform(93,89);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgTBGIAAhpIgpAAIAAgiIB5AAIAAAiIgqAAIAABpg");
	this.shape_12.setTransform(79.5,89);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAgBGIg6hMIAABMIgnAAIAAiLIAkAAIA5BJIAAhJIAmAAIAACLg");
	this.shape_13.setTransform(65,89);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgSBGIAAiLIAlAAIAACLg");
	this.shape_14.setTransform(53.9,89);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAaA4Igvg9IAAA9IgfAAIAAhvIAdAAIAtA6IAAg6IAfAAIAABvg");
	this.shape_15.setTransform(257.4,28.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgtA4IAAhvIBZAAIAAAaIg6AAIAAARIA1AAIAAAYIg1AAIAAARIA7AAIAAAbg");
	this.shape_16.setTransform(246.5,28.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAUA4IAAgrIgnAAIAAArIgfAAIAAhvIAfAAIAAAqIAnAAIAAgqIAfAAIAABvg");
	this.shape_17.setTransform(235.4,28.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgkAqQgRgRAAgZIAAAAQAAgYARgRQARgQAYAAQAeAAASAXIgYASQgKgNgOAAQgLAAgIAIQgHAJAAAMIAAAAQAAAMAHAJQAIAJALAAQAOAAALgOIAXARQgSAZgfAAQgXAAgRgQg");
	this.shape_18.setTransform(224.2,28.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgwAnIASgUQARANASAAQANAAAAgHIAAgBQAAgDgEgCQgEgDgKgDQgVgEgJgHQgNgHAAgQIAAAAQAAgQAMgKQAMgKATAAQAbAAATAPIgQAWQgPgLgPAAQgLAAAAAHIAAAAQAAAEAEADQAEACAKACQAVAFAKAHQALAIAAAOIAAAAQAAARgMAKQgNAKgUAAQgfAAgVgTg");
	this.shape_19.setTransform(213.3,28.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgPA4IAAhvIAfAAIAABvg");
	this.shape_20.setTransform(206.2,28.2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAWA5IgWhAIgWBAIgbAAIglhwIAhAAIATBAIAWhBIAZAAIAWBBIAUhAIAgAAIgmBwg");
	this.shape_21.setTransform(195.2,28.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgwA4IAAgWIA3g/Ig2AAIAAgaIBhAAIAAAWIg3A/IA3AAIAAAag");
	this.shape_22.setTransform(181.2,28.2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAaA4Igvg9IAAA9IgfAAIAAhvIAdAAIAtA6IAAg6IAfAAIAABvg");
	this.shape_23.setTransform(165.9,28.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgsA4IAAhvIBZAAIAAAaIg7AAIAAARIA1AAIAAAYIg1AAIAAARIA8AAIAAAbg");
	this.shape_24.setTransform(155,28.2);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgkAqQgSgRABgZIAAAAQgBgYASgRQAQgQAZAAQAbAAATAQIgTAWQgMgLgPAAQgLAAgIAJQgIAJAAAMIAAAAQAAAOAIAJQAJAIANAAQAKAAAIgEIAAgOIgXAAIAAgWIA0AAIAAAyQgVARgcAAQgZAAgRgQg");
	this.shape_25.setTransform(143.8,28.2);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AAaA4Igvg9IAAA9IgfAAIAAhvIAdAAIAtA6IAAg6IAfAAIAABvg");
	this.shape_26.setTransform(131.9,28.2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AglAtQgOgNAAgaIAAg+IAfAAIAAA9QAAAYAUAAQAVAAAAgXIAAg+IAfAAIAAA9QAAAbgOANQgOAMgYAAQgYAAgNgMg");
	this.shape_27.setTransform(120.1,28.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("Ag0A4IAAhvIArAAQAcAAASAPQAQAPAAAZQAAAZgRAPQgRAQgdAAgAgVAcIAMAAQAOAAAIgHQAIgIAAgNQAAgMgIgIQgIgIgOABIgMAAg");
	this.shape_28.setTransform(108.6,28.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAaA4Igvg9IAAA9IgfAAIAAhvIAdAAIAtA6IAAg6IAfAAIAABvg");
	this.shape_29.setTransform(96.5,28.2);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgPA4IAAhvIAfAAIAABvg");
	this.shape_30.setTransform(88.1,28.2);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgxA4IAAhvIA5AAQATAAALAKQAHAHAAALIAAABQAAARgRAIQAWAGAAAUQAAAOgLAJQgMAIgTAAgAgTAfIAXAAQAPAAAAgKIAAgBQAAgKgPABIgXAAgAgTgKIATAAQAPAAAAgKIAAgBQAAgJgPAAIgTAAg");
	this.shape_31.setTransform(80.6,28.2);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AAQA4IgWgiIgOAAIAAAiIgeAAIAAhvIA0AAQAYAAAMAMQAKAKAAAQIAAABQAAAXgXAKIAaAngAgUgBIAUAAQAIAAAFgEQADgEAAgGIAAAAQAAgNgQAAIgUAAg");
	this.shape_32.setTransform(69.8,28.2);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgsA4IAAhvIBZAAIAAAaIg7AAIAAARIA1AAIAAAYIg1AAIAAARIA7AAIAAAbg");
	this.shape_33.setTransform(59,28.2);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgNA5IguhxIAjAAIAYBGIAahGIAiAAIguBxg");
	this.shape_34.setTransform(47.9,28.3);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgtA4IAAhvIBZAAIAAAaIg6AAIAAARIA1AAIAAAYIg1AAIAAARIA7AAIAAAbg");
	this.shape_35.setTransform(278.3,10.2);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AAQA4IgWgiIgNAAIAAAiIggAAIAAhvIA0AAQAZAAAMAMQAKAKAAAQIAAABQAAAXgXAKIAbAngAgTgBIATAAQAIAAAEgEQAFgEAAgGIAAAAQAAgNgRAAIgTAAg");
	this.shape_36.setTransform(268.1,10.2);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgsA4IAAhvIBZAAIAAAaIg7AAIAAARIA1AAIAAAYIg1AAIAAARIA8AAIAAAbg");
	this.shape_37.setTransform(257.5,10.2);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AAUA4IAAgrIgnAAIAAArIgfAAIAAhvIAfAAIAAAqIAnAAIAAgqIAfAAIAABvg");
	this.shape_38.setTransform(246.6,10.2);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgkAqQgQgRAAgZIAAAAQAAgYAQgRQARgQAYAAQAeAAASAXIgYASQgLgNgNAAQgLAAgIAIQgHAJAAAMIAAAAQAAAMAHAJQAIAJALAAQAOAAALgOIAYARQgTAZgfAAQgXAAgRgQg");
	this.shape_39.setTransform(235.6,10.2);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgPA4IAAhvIAfAAIAABvg");
	this.shape_40.setTransform(227.7,10.2);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgwAnIASgUQARANASAAQANAAAAgHIAAgBQAAgDgEgCQgEgDgKgDQgVgEgJgHQgNgHAAgQIAAAAQAAgQAMgKQAMgKATAAQAbAAATAPIgQAWQgPgLgPAAQgLAAAAAHIAAAAQAAAEAEADQAEACAKACQAVAFAKAHQALAIAAAOIAAAAQAAARgMAKQgNAKgUAAQgfAAgVgTg");
	this.shape_41.setTransform(220.4,10.2);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgRARQARgBgBgOIgMAAIAAgeIAfAAIAAAaQAAAeggABg");
	this.shape_42.setTransform(209.9,15.6);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgtA4IAAhvIBZAAIAAAaIg6AAIAAARIA1AAIAAAYIg1AAIAAARIA7AAIAAAbg");
	this.shape_43.setTransform(203.5,10.2);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgPA4IAAhUIghAAIAAgbIBhAAIAAAbIghAAIAABUg");
	this.shape_44.setTransform(193.4,10.2);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AARA4IgbgqIgMANIAAAdIgfAAIAAhvIAfAAIAAAuIAmguIAlAAIgrAwIAsA/g");
	this.shape_45.setTransform(183.5,10.2);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgtA4IAAhvIBZAAIAAAaIg6AAIAAARIA1AAIAAAYIg1AAIAAARIA7AAIAAAbg");
	this.shape_46.setTransform(172.7,10.2);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AAQA4IgWgiIgNAAIAAAiIggAAIAAhvIA0AAQAZAAAMAMQAKAKAAAQIAAABQAAAXgXAKIAbAngAgTgBIATAAQAIAAAEgEQAFgEAAgGIAAAAQAAgNgRAAIgTAAg");
	this.shape_47.setTransform(162.5,10.2);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgPA4IAAhvIAfAAIAABvg");
	this.shape_48.setTransform(154.5,10.2);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("Ag0A4IAAhvIArAAQAcAAASAPQAQAPAAAZQAAAZgRAPQgRAQgdAAgAgVAdIAMAAQAOgBAIgHQAIgIAAgNQAAgMgIgIQgIgIgOABIgMAAg");
	this.shape_49.setTransform(146.6,10.2);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgRARQARgBgBgOIgMAAIAAgeIAfAAIAAAaQAAAeggABg");
	this.shape_50.setTransform(134.9,15.6);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgtA4IAAhvIBZAAIAAAaIg6AAIAAARIA1AAIAAAYIg1AAIAAARIA7AAIAAAbg");
	this.shape_51.setTransform(128.4,10.2);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AAQA4IgWgiIgNAAIAAAiIggAAIAAhvIA0AAQAZAAAMAMQAKAKAAAQIAAABQAAAXgXAKIAbAngAgTgBIATAAQAIAAAEgEQAFgEAAgGIAAAAQAAgNgRAAIgTAAg");
	this.shape_52.setTransform(118.2,10.2);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AAdA5IgIgVIgqAAIgIAVIghAAIAwhxIAdAAIAwBxgAAMAMIgMgfIgMAfIAYAAg");
	this.shape_53.setTransform(106.4,10.2);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgxA4IAAhvIA5AAQATAAALAKQAHAHAAALIAAABQAAARgRAIQAWAGAAAUQAAAOgLAJQgMAIgTAAgAgTAfIAXAAQAPAAAAgKIAAgBQAAgKgPABIgXAAgAgTgKIATAAQAPAAAAgKIAAgBQAAgJgOAAIgUAAg");
	this.shape_54.setTransform(95.4,10.2);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AAQA4IgWgiIgOAAIAAAiIgeAAIAAhvIA0AAQAYAAAMAMQAKAKAAAQIAAABQAAAXgXAKIAaAngAgUgBIAUAAQAIAAAEgEQAEgEAAgGIAAAAQAAgNgQAAIgUAAg");
	this.shape_55.setTransform(84.7,10.2);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgtA4IAAhvIBZAAIAAAaIg6AAIAAARIA1AAIAAAYIg1AAIAAARIA7AAIAAAbg");
	this.shape_56.setTransform(74.2,10.2);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AgPA4IAAhvIAfAAIAABvg");
	this.shape_57.setTransform(66.7,10.2);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgpA4IAAhvIAeAAIAABUIA1AAIAAAbg");
	this.shape_58.setTransform(60.2,10.2);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AAdA5IgIgVIgqAAIgIAVIghAAIAwhxIAdAAIAwBxgAAMAMIgMgfIgMAfIAYAAg");
	this.shape_59.setTransform(49.3,10.2);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AARA4IgbgqIgMANIAAAdIgfAAIAAhvIAfAAIAAAuIAmguIAlAAIgrAwIAsA/g");
	this.shape_60.setTransform(38.4,10.2);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgwAnIASgUQARANASAAQANAAAAgHIAAgBQAAgDgEgCQgEgDgKgDQgVgEgJgHQgNgHAAgQIAAAAQAAgQAMgKQAMgKATAAQAbAAATAPIgQAWQgPgLgPAAQgLAAAAAHIAAAAQAAAEAEADQAEACAKACQAVAFAKAHQALAIAAAOIAAAAQAAARgMAKQgNAKgUAAQgfAAgVgTg");
	this.shape_61.setTransform(27.3,10.2);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgGAJIAAgQIANAAIAAAQg");
	this.shape_62.setTransform(188.8,69);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AAlA4IhHhbIAABbIgMAAIAAhvIALAAIBGBZIAAhZIAMAAIAABvg");
	this.shape_63.setTransform(181.1,64.2);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgoA4IAAhvIBQAAIAAAMIhDAAIAAAlIA8AAIAAALIg8AAIAAAoIBEAAIAAALg");
	this.shape_64.setTransform(170.2,64.2);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgGA4IAAhjIglAAIAAgMIBXAAIAAAMIgmAAIAABjg");
	this.shape_65.setTransform(159.9,64.2);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AArA5IgNgeIg8AAIgNAeIgNAAIAzhxIALAAIAzBxgAAZAPIgZg3IgZA3IAyAAg");
	this.shape_66.setTransform(148.9,64.2);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgwA4IAAhvIAnAAQAZAAAQAQQARAQAAAXIAAAAQAAAYgRAQQgQAQgZAAgAgjAtIAaAAQATgBANgNQANgMAAgSIAAgBQAAgSgNgNQgNgNgTABIgaAAg");
	this.shape_67.setTransform(137.1,64.2);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AAWAoQgQARgTAAQgQAAgJgIQgLgJAAgOQAAgWAbgKQgLgNAAgLIAAgBQAAgLAIgHQAJgIANAAQALAAAHAHQAIAIAAAKQAAAUgZAKIAYAZQAHgLAHgNIAKADQgIATgIAKIAUAUIgKAHgAgkAZIAAABQAAAJAHAGQAGAGALAAQANAAAOgPIgdgfQgWAIAAAQgAgQgqQgFAEAAAHIAAABQAAAIAMAMQAUgHAAgOIAAAAQAAgHgEgEQgFgFgGAAQgHAAgFAFg");
	this.shape_68.setTransform(121.4,64.2);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AgpAnIAIgJQASAQATAAQAMAAAGgFQAHgGAAgIQAAgIgGgFQgGgFgRgEQgTgEgIgGQgJgIAAgMIAAgBQgBgNALgJQAKgJAQAAQAVAAASAOIgIAKQgPgMgQAAQgLgBgGAGQgHAFAAAIQAAAIAGAFQAHAFAQAEQAUAEAIAGQAJAIAAANIAAAAQAAAOgLAJQgLAIgRAAQgYABgUgTg");
	this.shape_69.setTransform(263,46.2);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AgwA4IAAhvIAmAAQAaAAAQAQQARAQAAAXIAAAAQAAAYgRAQQgQAQgaAAgAgkAtIAaAAQAVgBAMgNQANgMAAgSIAAgBQAAgSgNgNQgMgNgVABIgaAAg");
	this.shape_70.setTransform(252.5,46.2);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AghAtQgNgNAAgYIAAhAIANAAIAABAQAAASAJAJQAJAKAPAAQAQAAAJgJQAJgKAAgSIAAhAIANAAIAAA/QAAAYgNANQgNANgVAAQgUAAgNgMg");
	this.shape_71.setTransform(240.4,46.3);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AgoAoQgQgQAAgXIAAgBQAAgXAQgRQAQgRAYAAQAZAAAQARQAQARAAAXIAAAAQAAAYgQAQQgQASgZAAQgYAAgQgSgAgeggQgNANAAATIAAAAQAAATANANQAMAOASAAQATAAANgNQAMgOAAgSIAAgBQAAgSgMgOQgNgNgTAAQgSAAgMANg");
	this.shape_72.setTransform(228.1,46.2);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AglA4IAAhvIANAAIAABkIA+AAIAAALg");
	this.shape_73.setTransform(217.2,46.2);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgiApQgPgQAAgYIAAgBQAAgXAPgRQARgRAXAAQAZAAATASIgJAJQgQgPgTAAQgRAAgNANQgNANAAATIAAAAQAAAUANANQANANARAAQATAAARgQIAJAIQgUAUgZAAQgXAAgRgRg");
	this.shape_74.setTransform(206.7,46.2);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgJANQALgEgBgJIgFAAIAAgRIAOAAIAAAOQAAAJgFAFQgEAFgIACg");
	this.shape_75.setTransform(194.6,51.9);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AAlA4IhHhbIAABbIgMAAIAAhvIALAAIBGBZIAAhZIAMAAIAABvg");
	this.shape_76.setTransform(187.1,46.2);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AgoA4IAAhvIBQAAIAAAMIhDAAIAAAlIA8AAIAAALIg8AAIAAAoIBEAAIAAALg");
	this.shape_77.setTransform(176.2,46.2);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AgGA4IAAhjIglAAIAAgMIBXAAIAAAMIgmAAIAABjg");
	this.shape_78.setTransform(165.9,46.2);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AAfA4IgggsIggAAIAAAsIgMAAIAAhvIAvAAQAUAAAMALQAIAJAAANQAAAOgIAIQgIAHgOADIAiAugAghABIAiAAQAMAAAIgFQAIgHAAgKQAAgLgHgFQgIgHgNABIgiAAg");
	this.shape_79.setTransform(155.9,46.2);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AgoAoQgQgQAAgXIAAgBQAAgXAQgRQAQgRAYAAQAZAAARARQAPARAAAXIAAAAQAAAYgPAQQgRASgZAAQgYAAgQgSgAgeggQgNANAAATIAAAAQAAATANANQAMAOASAAQATAAANgNQAMgOAAgSIAAgBQAAgSgMgOQgNgNgTAAQgSAAgMANg");
	this.shape_80.setTransform(143.4,46.2);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AgJANQALgEgBgJIgFAAIAAgRIAOAAIAAAOQAAAJgFAFQgEAFgIACg");
	this.shape_81.setTransform(130.6,51.9);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AAlA4IhHhbIAABbIgMAAIAAhvIALAAIBGBZIAAhZIAMAAIAABvg");
	this.shape_82.setTransform(123.1,46.2);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AgoA4IAAhvIBQAAIAAAMIhDAAIAAAlIA8AAIAAALIg8AAIAAAoIBEAAIAAALg");
	this.shape_83.setTransform(112.2,46.2);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AAgA4IAAgzIhAAAIAAAzIgMAAIAAhvIAMAAIAAAxIBAAAIAAgxIANAAIAABvg");
	this.shape_84.setTransform(101,46.2);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AghApQgQgQgBgYIAAgBQABgXAQgRQAPgRAYAAQAZAAASASIgIAJQgQgPgTAAQgRAAgNANQgMANAAATIAAAAQAAAUAMANQANANARAAQATAAARgQIAIAIQgTAUgaAAQgWAAgQgRg");
	this.shape_85.setTransform(89.8,46.2);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AgpAnIAIgJQASAQATAAQAMAAAGgFQAHgGAAgIQAAgIgGgFQgGgFgRgEQgTgEgIgGQgJgIAAgMIAAgBQgBgNALgJQAKgJAQAAQAVAAARAOIgHAKQgPgMgQAAQgLgBgGAGQgHAFAAAIQAAAIAGAFQAHAFAQAEQAUAEAIAGQAJAIAAANIAAAAQAAAOgLAJQgLAIgRAAQgYABgUgTg");
	this.shape_86.setTransform(79,46.2);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AAlA4IhHhbIAABbIgMAAIAAhvIALAAIBGBZIAAhZIAMAAIAABvg");
	this.shape_87.setTransform(68.1,46.2);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AgoA4IAAhvIBQAAIAAAMIhDAAIAAAlIA8AAIAAALIg8AAIAAAoIBEAAIAAALg");
	this.shape_88.setTransform(57.3,46.2);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AApA4IAAhaIgpA8IAAAAIgpg8IAABaIgLAAIAAhvIAMAAIAoA8IAog8IAOAAIAABvg");
	this.shape_89.setTransform(45.2,46.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtEnd, new cjs.Rectangle(0,1,306,101), null);


(lib.txt4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAnBUIhHhbIAABbIguAAIAAinIArAAIBEBYIAAhYIAuAAIAACng");
	this.shape.setTransform(266.8,12.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhAA+QgagZAAgkIAAgBQAAgjAagaQAagaAmAAQAnAAAaAaQAaAZAAAkIAAAAQAAAlgaAZQgbAZgmAAQgmAAgagZgAgfgfQgLANAAASIAAAAQAAATAMAMQAMAOASABQATAAAMgOQALgNAAgSIAAgBQABgSgMgNQgMgNgTAAQgSAAgNANg");
	this.shape_1.setTransform(247.5,12.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgWBUIAAinIAtAAIAACng");
	this.shape_2.setTransform(233.6,12.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgWBUIAAh+IgzAAIAAgpICTAAIAAApIgzAAIAAB+g");
	this.shape_3.setTransform(221.8,12.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag2A/QgZgZAAglIAAgBQAAgkAZgZQAZgaAlAAQAuAAAZAkIgjAbQgQgUgVAAQgQAAgLANQgMANAAASIAAAAQAAATAMANQALANAQAAQAWAAAQgVIAjAZQgbAmgvAAQgjABgZgZg");
	this.shape_4.setTransform(205.4,12.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhDBUIAAinICGAAIAAAoIhYAAIAAAZIBQAAIAAAkIhQAAIAAAbIBZAAIAAAng");
	this.shape_5.setTransform(188.7,12.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAnBUIhHhbIAABbIguAAIAAinIArAAIBEBYIAAhYIAuAAIAACng");
	this.shape_6.setTransform(171,12.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAnBUIhHhbIAABbIguAAIAAinIArAAIBEBYIAAhYIAuAAIAACng");
	this.shape_7.setTransform(152.2,12.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhAA+QgZgZgBgkIAAgBQAAgjAagaQAbgaAlAAQAnAAAZAaQAaAZAAAkIAAAAQAAAlgaAZQgaAZgmAAQgmAAgagZgAgegfQgMANAAASIAAAAQAAATAMAMQAMAOASABQASAAANgOQAMgNAAgSIAAgBQgBgSgLgNQgMgNgTAAQgSAAgMANg");
	this.shape_8.setTransform(132.9,12.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag2A/QgZgZAAglIAAgBQAAgkAZgZQAZgaAlAAQAuAAAZAkIgjAbQgQgUgVAAQgQAAgLANQgMANAAASIAAAAQAAATAMANQALANAQAAQAWAAAQgVIAjAZQgbAmgvAAQgjABgZgZg");
	this.shape_9.setTransform(114.4,12.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAYBUIghgzIgVAAIAAAzIguAAIAAinIBOAAQAlAAASASQAPAPAAAYIAAABQAAAkgjAPIAoA6gAgegDIAeAAQAMAAAGgEQAHgGAAgJIAAgBQAAgUgZAAIgeAAg");
	this.shape_10.setTransform(97.4,12.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhDBUIAAinICGAAIAAAoIhYAAIAAAZIBQAAIAAAkIhQAAIAAAbIBZAAIAAAng");
	this.shape_11.setTransform(80.5,12.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgWBUIAAh+IgzAAIAAgpICTAAIAAApIgzAAIAAB+g");
	this.shape_12.setTransform(64.3,12.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAnBUIhHhbIAABbIguAAIAAinIArAAIBEBYIAAhYIAuAAIAACng");
	this.shape_13.setTransform(47,12.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgWBUIAAinIAtAAIAACng");
	this.shape_14.setTransform(33.7,12.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txt4, new cjs.Rectangle(0,0,306,28), null);


(lib.txt3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgKBRIAAgTIAOAAIAAATgAgGAoIgDgmIACgBQAVAAAMgKQANgJAAgRIAAgBQAAgOgKgJQgLgLgRAAQgYAAgTAXIgIgGQAVgbAfgBQAVABAPANQANAMAAATIAAAAQAAAVgOANQgNAKgVACIgCAeg");
	this.shape.setTransform(288.5,81.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAyBQIgyhCIg0AAIAABCIgNAAIAAigIBDAAQAeAAAPAQQAMAMAAATQAAATgNAMQgMALgWADIA2BEgAg0ADIA1AAQAUAAAOgIQANgLgBgRIAAAAQABgRgMgJQgNgJgVAAIg2AAg");
	this.shape_1.setTransform(276.1,81.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag6A6QgWgYAAgiIAAAAQAAghAWgYQAYgZAiAAQAkAAAXAYQAWAYAAAiIAAAAQAAAigWAYQgYAZgjAAQgjAAgXgZgAgwgzQgUAVAAAeIAAAAQAAAeAUAVQAUAVAcAAQAeAAATgVQAUgVAAgeIAAAAQAAgdgUgVQgUgWgdAAQgdAAgTAVg");
	this.shape_2.setTransform(258.5,81.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgEBRIhHihIANAAIA+CTIA/iTIANAAIhHChg");
	this.shape_3.setTransform(241.3,81.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAlBQIhEhXIAABXIgsAAIAAigIApAAIBCBVIAAhVIAsAAIAACgg");
	this.shape_4.setTransform(219.2,81.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag9A7QgZgYAAgjIAAAAQAAgiAZgYQAZgZAkAAQAlAAAZAYQAZAYAAAjIAAAAQAAAjgZAYQgZAZglAAQgkAAgZgZgAgdgeQgLAMAAASIAAAAQAAASALAMQAMANARAAQASAAAMgNQALgMAAgSIAAAAQAAgRgMgNQgLgNgSAAQgRAAgMANg");
	this.shape_5.setTransform(201.8,81.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgVBQIAAigIArAAIAACgg");
	this.shape_6.setTransform(189.7,81.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgVBQIAAh4IgxAAIAAgoICNAAIAAAoIgxAAIAAB4g");
	this.shape_7.setTransform(179.6,81.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAqBRIgMgdIg9AAIgLAdIgvAAIBEihIAqAAIBFChgAASASIgSgtIgRAtIAjAAg");
	this.shape_8.setTransform(164.1,81.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AApBQIAAhbIgpA+IAAAAIgpg+IAABbIgsAAIAAigIAwAAIAlA/IAmg/IAvAAIAACgg");
	this.shape_9.setTransform(146.2,81.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAXBQIgggwIgTAAIAAAwIgtAAIAAigIBLAAQAjABARARQAOAOABAYQAAAigiAOIAnA4gAgcgCIAcAAQALAAAGgGQAHgEAAgJIAAgBQAAgTgYAAIgcAAg");
	this.shape_10.setTransform(129.8,81.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("Ag9A7QgZgYAAgjIAAAAQAAgiAZgYQAZgZAkAAQAlAAAZAYQAZAYAAAjIAAAAQAAAjgZAYQgZAZglAAQgkAAgZgZgAgdgeQgLAMAAASIAAAAQAAASALAMQAMANARAAQASAAAMgNQALgMAAgSIAAAAQAAgRgMgNQgLgNgSAAQgRAAgMANg");
	this.shape_11.setTransform(112.6,81.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag/BQIAAigIB/AAIAAAoIhTAAIAAAbIBLAAIAAAkIhLAAIAAA5g");
	this.shape_12.setTransform(97.2,81.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhFA4IAZgdQAYATAbAAQASAAAAgLIAAgBQAAgFgFgDQgGgDgPgEQgegHgNgJQgSgLAAgWIAAgBQAAgXARgOQARgOAcAAQAnAAAbAVIgWAfQgWgPgWAAQgRAAAAAKIAAAAQAAAGAGADQAGADAQAEQAeAHANAKQAQALAAAVIAAABQAAAYgRAOQgSAOgeAAQgsAAgegbg");
	this.shape_13.setTransform(82.8,81.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAlBQIhEhXIAABXIgsAAIAAigIApAAIBCBVIAAhVIAsAAIAACgg");
	this.shape_14.setTransform(67.8,81.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAqBRIgMgdIg9AAIgLAdIgvAAIBFihIApAAIBFChgAASASIgSgtIgRAtIAjAAg");
	this.shape_15.setTransform(50.8,81.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAWBQIgfgwIgUAAIAAAwIgsAAIAAigIBLAAQAjABASARQAOAOgBAYQAAAiggAOIAmA4gAgdgCIAdAAQALAAAHgGQAGgEAAgJIAAgBQAAgTgYAAIgdAAg");
	this.shape_16.setTransform(35.2,81.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgWBQIAAh4IgvAAIAAgoICMAAIAAAoIgxAAIAAB4g");
	this.shape_17.setTransform(20,81.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AhABRIAAigICAAAIAAAlIhUAAIAAAZIBMAAIAAAiIhMAAIAAAaIBVAAIAAAmg");
	this.shape_18.setTransform(220.6,58.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("Ag8BRIAAigIAsAAIAAB4IBNAAIAAAog");
	this.shape_19.setTransform(207,58.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAqBRIgMgdIg9AAIgLAdIgvAAIBEihIArAAIBEChgAASARIgSgtIgRAtIAjAAg");
	this.shape_20.setTransform(191.4,58.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgVBRIAAh6IgxAAIAAgmICMAAIAAAmIgwAAIAAB6g");
	this.shape_21.setTransform(175.7,58.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgVBRIAAigIArAAIAACgg");
	this.shape_22.setTransform(165.3,58.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("Ag1A8QgZgXAAglIAAAAQAAgjAZgYQAZgYAkAAQAmAAAbAXIgaAgQgSgPgVAAQgQAAgMANQgMAMAAASIAAAAQAAAUAMANQAMAMASAAQAQAAAKgHIAAgTIgfAAIAAggIBKAAIAABHQgeAagoAAQglAAgZgYg");
	this.shape_23.setTransform(153.7,58.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgVBRIAAigIArAAIAACgg");
	this.shape_24.setTransform(142.2,58.4);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AhLBRIAAigIA+AAQApgBAZAXQAXAVAAAkIAAAAQAAAjgYAWQgZAYgpAAgAgfApIASAAQAUAAAMgLQAMgLAAgTQAAgSgMgMQgMgKgUAAIgSAAg");
	this.shape_25.setTransform(130.9,58.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AhABRIAAigICAAAIAAAlIhUAAIAAAZIBMAAIAAAiIhMAAIAAAaIBVAAIAAAmg");
	this.shape_26.setTransform(110.1,58.4);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgVBRIAAigIArAAIAACgg");
	this.shape_27.setTransform(99.4,58.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AhLBRIAAigIA+AAQApgBAZAXQAXAVAAAkIAAAAQAAAjgYAWQgZAYgpAAgAgfApIASAAQAUAAAMgLQAMgLAAgTQAAgSgMgMQgMgKgUAAIgSAAg");
	this.shape_28.setTransform(88.1,58.4);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("Ag4BQIAAigIBxAAIAAAMIhlAAIAABCIBaAAIAAAJIhaAAIAABJg");
	this.shape_29.setTransform(284.8,35.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgvBAQgSgTAAghIAAhdIAMAAIAABcQAAAcAOAQQAOAQAZAAQAaAAAOgPQAOgPAAgdIAAhdIAMAAIAABcQAAAigSATQgSASgeAAQgdAAgSgSg");
	this.shape_30.setTransform(269,35.5);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("ABEBRIgVgtIheAAIgUAtIgNAAIBLihIALAAIBLChgAAqAZIgqhcIgqBcIBUAAg");
	this.shape_31.setTransform(252.2,35.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AAzBQIgzhCIg1AAIAABCIgLAAIAAigIBCAAQAdAAAQAQQAMANABARQAAAUgOAMQgNALgUADIA0BEgAg1ADIA1AAQAWAAAMgIQANgLAAgRIAAgBQAAgPgMgKQgMgKgWABIg2AAg");
	this.shape_32.setTransform(230.6,35.4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("Ag5BQIAAigIByAAIAAAMIhmAAIAAA/IBbAAIAAAKIhbAAIAABAIBnAAIAAALg");
	this.shape_33.setTransform(215.4,35.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AAyBQIgyhCIg0AAIAABCIgMAAIAAigIBCAAQAeAAAPAQQAMANAAARQAAAUgNAMQgMALgWADIA1BEgAg0ADIA1AAQAUAAAOgIQANgLgBgRIAAgBQABgPgMgKQgNgKgWABIg1AAg");
	this.shape_34.setTransform(200.6,35.4);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AA0BQIAAhLIhnAAIAABLIgLAAIAAigIALAAIAABLIBnAAIAAhLIAMAAIAACgg");
	this.shape_35.setTransform(183.9,35.4);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AguBPQgTgSAAghIAAhdIAMAAIAABcQAAAcAPAQQAOAQAYAAQAZAAAOgPQAPgPAAgdIAAhdIAMAAIAABbQAAAjgTASQgRASgeAAQgdAAgRgSgAAMhPIAAgSIAQAAIAAASgAgbhPIAAgSIARAAIAAASg");
	this.shape_36.setTransform(167.5,33.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("Ag4BQIAAigIBxAAIAAAMIhlAAIAABCIBaAAIAAAJIhaAAIAABJg");
	this.shape_37.setTransform(152.7,35.4);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AA6BQIhxiOIAACOIgLAAIAAigIALAAIBuCMIAAiMIAMAAIAACgg");
	this.shape_38.setTransform(136.6,35.4);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("Ag5BQIAAigIByAAIAAAMIhmAAIAAA/IBbAAIAAAKIhbAAIAABAIBnAAIAAALg");
	this.shape_39.setTransform(121.3,35.4);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AAzBQIAAhLIhlAAIAABLIgMAAIAAigIAMAAIAABLIBlAAIAAhLIANAAIAACgg");
	this.shape_40.setTransform(105.4,35.4);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgwA7QgXgYAAgjIAAAAQAAgiAXgYQAXgYAhAAQAUAAAQAHQANAGAOAMIgJAJQgYgYgeAAQgcAAgTAVQgUAVAAAeIAAAAQAAAeAUAVQAUAVAbAAQAeAAAZgZIAJAIQgdAcgjAAQgiAAgWgYg");
	this.shape_41.setTransform(89.6,35.4);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AA6BQIhwiOIAACOIgMAAIAAigIALAAIBvCMIAAiMIALAAIAACgg");
	this.shape_42.setTransform(72.7,35.4);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("ABEBRIgVgtIheAAIgUAtIgNAAIBLihIALAAIBLChgAAqAZIgqhcIgqBcIBUAAg");
	this.shape_43.setTransform(55.5,35.3);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AAzBQIgzhCIg1AAIAABCIgLAAIAAigIBCAAQAdAAAQAQQAMANABARQAAAUgOAMQgNALgUADIA0BEgAg1ADIA1AAQAWAAANgIQAMgLAAgRIAAgBQAAgPgMgKQgMgKgWABIg2AAg");
	this.shape_44.setTransform(39.8,35.4);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("Ag/BQIAAigIBCAAQAbAAAPAPQAKAKAAAPIAAABQAAAagcALQAlAJAAAdIAAAAQAAAVgQAMQgQAMgagBgAgzBFIA6AAQAUABAMgKQANgIAAgQIAAAAQAAgPgNgIQgNgIgXAAIg2AAgAgzgFIA0AAQATAAALgIQAMgKAAgPIAAgBQAAgNgLgIQgLgJgTABIg1AAg");
	this.shape_45.setTransform(24,35.4);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AAzBRIAAhMIhlAAIAABMIgNAAIAAigIANAAIAABKIBlAAIAAhKIANAAIAACgg");
	this.shape_46.setTransform(254.7,12.4);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgxA7QgWgYAAgjIAAAAQAAgiAWgYQAYgYAiAAQATAAAQAHQANAGAOAMIgIAJQgZgYgeAAQgcAAgUAVQgTAVAAAeIAAAAQAAAeAUAVQATAVAdAAQAdAAAagZIAIAIQgdAcgjAAQghAAgYgYg");
	this.shape_47.setTransform(238.9,12.4);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgFBRIAAigIALAAIAACgg");
	this.shape_48.setTransform(227.9,12.4);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("Ag6A5IAIgJQAaAYAeAAQATAAALgJQAMgJAAgOIAAAAQAAgOgKgHQgKgIgagFQgcgGgNgKQgMgKAAgTIAAAAQAAgSAOgMQAPgNAWAAQAeAAAZAUIgIAJQgVgSgaAAQgRAAgMAJQgLAJAAANIAAAAQAAAOAJAHQALAJAaAFQAcAFANALQAMAKAAASIAAAAQAAAUgPAMQgPAMgXAAQgjAAgdgag");
	this.shape_49.setTransform(218.3,12.3);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AAlBRIhEhYIAABYIgsAAIAAigIAqAAIBBBTIAAhTIAsAAIAACgg");
	this.shape_50.setTransform(197.1,12.4);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AhABRIAAigICAAAIAAAlIhUAAIAAAZIBMAAIAAAiIhMAAIAAAZIBVAAIAAAng");
	this.shape_51.setTransform(181.7,12.4);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgWBRIAAh6IgvAAIAAgmICMAAIAAAmIgxAAIAAB6g");
	this.shape_52.setTransform(167.2,12.4);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgVBRIAAigIArAAIAACgg");
	this.shape_53.setTransform(156.8,12.4);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AhABRIAAigICAAAIAAAlIhUAAIAAAZIBMAAIAAAiIhMAAIAAAZIBVAAIAAAng");
	this.shape_54.setTransform(146.7,12.4);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AAWBRIgfgxIgUAAIAAAxIgsAAIAAigIBLAAQAjAAASARQANAOAAAYQAAAjggANIAmA5gAgdgCIAdAAQALAAAHgFQAGgGAAgJIAAAAQAAgTgYAAIgdAAg");
	this.shape_55.setTransform(132.1,12.4);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AhABRIAAigICAAAIAAAlIhUAAIAAAZIBMAAIAAAiIhMAAIAAAZIBVAAIAAAng");
	this.shape_56.setTransform(116.8,12.4);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AhHBRIAAigIBSAAQAdgBAOAOQALAMAAAPIAAAAQAAAagZAKQAgAKAAAdIAAAAQAAAVgQALQgQANgdAAgAgcAtIAiAAQAVAAAAgPIAAAAQAAgPgVAAIgiAAgAgcgPIAcAAQAVgBAAgOIAAAAQAAgNgUAAIgdAAg");
	this.shape_57.setTransform(102.1,12.4);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("Ag5BRIAAigIByAAIAAALIhmAAIAAA/IBbAAIAAAKIhbAAIAABAIBnAAIAAAMg");
	this.shape_58.setTransform(81.3,12.4);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AgFBRIAAigIALAAIAACgg");
	this.shape_59.setTransform(71,12.4);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AAvBRIgviKIguCKIgKAAIg6ihIANAAIAzCPIAviPIAIAAIAvCPIAziPIAMAAIg6Chg");
	this.shape_60.setTransform(56.2,12.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txt3, new cjs.Rectangle(0,0,306,96), null);


(lib.txt2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAnBUIhHhbIAABbIguAAIAAinIArAAIBEBYIAAhYIAuAAIAACng");
	this.shape.setTransform(266.8,12.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhAA+QgagZAAgkIAAgBQAAgjAagaQAagaAmAAQAnAAAaAaQAaAZAAAkIAAAAQAAAlgaAZQgbAZgmAAQgmAAgagZgAgfgfQgLANAAASIAAAAQAAATAMAMQAMAOASABQATAAAMgOQALgNAAgSIAAgBQABgSgMgNQgMgNgTAAQgSAAgNANg");
	this.shape_1.setTransform(247.5,12.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgWBUIAAinIAtAAIAACng");
	this.shape_2.setTransform(233.6,12.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgWBUIAAh+IgzAAIAAgpICTAAIAAApIgzAAIAAB+g");
	this.shape_3.setTransform(221.8,12.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag2A/QgZgZAAglIAAgBQAAgkAZgZQAZgaAlAAQAuAAAZAkIgjAbQgQgUgVAAQgQAAgLANQgMANAAASIAAAAQAAATAMANQALANAQAAQAWAAAQgVIAjAZQgbAmgvAAQgjABgZgZg");
	this.shape_4.setTransform(205.4,12.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhDBUIAAinICGAAIAAAoIhYAAIAAAZIBQAAIAAAkIhQAAIAAAbIBZAAIAAAng");
	this.shape_5.setTransform(188.7,12.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAnBUIhHhbIAABbIguAAIAAinIArAAIBEBYIAAhYIAuAAIAACng");
	this.shape_6.setTransform(171,12.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAnBUIhHhbIAABbIguAAIAAinIArAAIBEBYIAAhYIAuAAIAACng");
	this.shape_7.setTransform(152.2,12.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhAA+QgZgZgBgkIAAgBQAAgjAagaQAbgaAlAAQAnAAAZAaQAaAZAAAkIAAAAQAAAlgaAZQgaAZgmAAQgmAAgagZgAgegfQgMANAAASIAAAAQAAATAMAMQAMAOASABQASAAANgOQAMgNAAgSIAAgBQgBgSgLgNQgMgNgTAAQgSAAgMANg");
	this.shape_8.setTransform(132.9,12.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag2A/QgZgZAAglIAAgBQAAgkAZgZQAZgaAlAAQAuAAAZAkIgjAbQgQgUgVAAQgQAAgLANQgMANAAASIAAAAQAAATAMANQALANAQAAQAWAAAQgVIAjAZQgbAmgvAAQgjABgZgZg");
	this.shape_9.setTransform(114.4,12.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAYBUIghgzIgVAAIAAAzIguAAIAAinIBOAAQAlAAASASQAPAPAAAYIAAABQAAAkgjAPIAoA6gAgegDIAeAAQAMAAAGgEQAHgGAAgJIAAgBQAAgUgZAAIgeAAg");
	this.shape_10.setTransform(97.4,12.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhDBUIAAinICGAAIAAAoIhYAAIAAAZIBQAAIAAAkIhQAAIAAAbIBZAAIAAAng");
	this.shape_11.setTransform(80.5,12.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgWBUIAAh+IgzAAIAAgpICTAAIAAApIgzAAIAAB+g");
	this.shape_12.setTransform(64.3,12.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAnBUIhHhbIAABbIguAAIAAinIArAAIBEBYIAAhYIAuAAIAACng");
	this.shape_13.setTransform(47,12.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgWBUIAAinIAtAAIAACng");
	this.shape_14.setTransform(33.7,12.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txt2, new cjs.Rectangle(0,0,306,28), null);


(lib.txt1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgKBVIAAgVIAPAAIAAAVgAgGApIgDgnIABgBQAXAAANgKQANgKAAgRIAAgBQAAgPgLgKQgLgLgSAAQgZAAgUAYIgJgGQAXgdAgAAQAXAAAPANQAOAOAAAUIAAAAQAAAWgPANQgOAKgWADIgCAeg");
	this.shape.setTransform(269.7,60.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgFBUIAAicIg7AAIAAgLICBAAIAAALIg7AAIAACcg");
	this.shape_1.setTransform(256.3,60.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag7BUIAAinIB2AAIAAALIhqAAIAABCIBfAAIAAALIhfAAIAABDIBrAAIAAAMg");
	this.shape_2.setTransform(241.5,60.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AA9BUIh2iUIAACUIgMAAIAAinIAMAAIBzCRIAAiRIAMAAIAACng");
	this.shape_3.setTransform(224,60.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AA1BUIg1hFIg3AAIAABFIgMAAIAAinIBFAAQAfAAARARQAMAMAAATQAAAUgOAOQgNAKgWADIA3BIgAg3ADIA4AAQAVAAAOgJQAOgLAAgSIAAAAQAAgRgNgKQgNgKgWAAIg5AAg");
	this.shape_4.setTransform(207,60.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag7BUIAAinIB2AAIAAALIhqAAIAABCIBfAAIAAALIhfAAIAABDIBrAAIAAAMg");
	this.shape_5.setTransform(190.6,60.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgFBUIAAicIg7AAIAAgLICBAAIAAALIg7AAIAACcg");
	this.shape_6.setTransform(174.8,60.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AA9BUIh2iUIAACUIgMAAIAAinIAMAAIBzCRIAAiRIAMAAIAACng");
	this.shape_7.setTransform(158.1,60.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgFBUIAAinIALAAIAACng");
	this.shape_8.setTransform(145.8,60.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag9A8IAJgKQAbAZAgAAQATAAALgKQAMgJAAgOIAAgBQAAgNgJgJQgLgIgbgFQgdgGgOgKQgNgLAAgUIAAAAQAAgTAPgMQAQgOAXAAQAfABAaAUIgIAKQgWgTgbAAQgSAAgMAJQgLAJAAANIAAABQAAAOAJAIQALAJAcAGQAdAFANALQANALAAASIAAABQAAAUgQAMQgPAOgZAAQgkAAgfgbg");
	this.shape_9.setTransform(128.6,60.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("ABHBVIgWgvIhiAAIgVAvIgNAAIBOipIALAAIBOCpgAAsAaIgshgIgsBgIBYAAg");
	this.shape_10.setTransform(112,60.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhIBUIAAinIA5AAQAlAAAaAYQAZAYAAAjIAAAAQAAAkgZAYQgaAYglAAgAg7BIIAsAAQAhAAAVgUQAVgVgBgfIAAAAQABgegVgUQgVgWghAAIgsAAg");
	this.shape_11.setTransform(94.1,60.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag7BUIAAinIB2AAIAAALIhqAAIAABCIBfAAIAAALIhfAAIAABDIBrAAIAAAMg");
	this.shape_12.setTransform(70.6,60.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgFBUIAAinIALAAIAACng");
	this.shape_13.setTransform(59.3,60.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAxBVIgxiRIgwCRIgKAAIg9ioIAOAAIA1CUIAxiVIAIAAIAxCVIA1iUIANAAIg9Cog");
	this.shape_14.setTransform(43.3,60.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ag/BUIAAinIAuAAIAAB+IBRAAIAAApg");
	this.shape_15.setTransform(282.9,36.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("Ag/BUIAAinIAuAAIAAB+IBRAAIAAApg");
	this.shape_16.setTransform(268.6,36.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AhDBUIAAinICGAAIAAAnIhYAAIAAAaIBPAAIAAAkIhPAAIAAAaIBZAAIAAAog");
	this.shape_17.setTransform(253.5,36.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAnBUIhHhbIAABbIguAAIAAinIArAAIBEBYIAAhYIAuAAIAACng");
	this.shape_18.setTransform(236.3,36.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAeBUIAAhAIg7AAIAABAIgvAAIAAinIAvAAIAAA/IA7AAIAAg/IAuAAIAACng");
	this.shape_19.setTransform(218.3,36.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("Ag2A+QgZgZAAglIAAAAQAAgkAZgZQAZgZAlAAQAuAAAZAjIgjAbQgQgUgVAAQgQAAgLANQgMANAAASIAAAAQAAATAMANQALANAQAAQAWAAAQgVIAjAaQgbAmgvgBQgjAAgZgZg");
	this.shape_20.setTransform(201.1,36.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AhIA7IAagfQAaAVAbAAQAUAAgBgMIAAgBQAAgFgFgEQgGgDgQgEQgggHgNgJQgSgMAAgXIAAgBQAAgYARgPQASgPAdAAQApAAAcAWIgYAiQgXgRgWAAQgRAAgBAKIAAABQAAAGAHADQAFAEARADQAfAIAOAKQASALgBAXIAAAAQABAZgUAPQgRAPgfAAQgvAAgfgcg");
	this.shape_21.setTransform(184.6,36.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AhAA+QgagZABglIAAAAQAAgkAagZQAagZAlAAQAmAAAaAZQAbAZAAAkIAAAAQAAAlgbAYQgaAagmAAQgmABgagagAgfgfQgLANAAASIAAAAQAAASAMAOQAMANASAAQATAAAMgNQAMgNAAgTIAAAAQAAgSgNgNQgMgOgSAAQgTAAgMAOg");
	this.shape_22.setTransform(161.5,36.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AhIA7IAagfQAaAVAbAAQAUAAAAgMIAAgBQgBgFgFgEQgGgDgQgEQgggHgNgJQgSgMAAgXIAAgBQAAgYARgPQASgPAdAAQApAAAcAWIgXAiQgXgRgXAAQgRAAAAAKIAAABQgBAGAHADQAFAEARADQAfAIAOAKQARALAAAXIAAAAQAAAZgTAPQgRAPgfAAQgvAAgfgcg");
	this.shape_23.setTransform(144,36.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgWBUIAAh+IgzAAIAAgpICTAAIAAApIgzAAIAAB+g");
	this.shape_24.setTransform(122.9,36.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("Ag/BUIAAinIAuAAIAAB+IBRAAIAAApg");
	this.shape_25.setTransform(108.6,36.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AhDBUIAAinICGAAIAAAnIhYAAIAAAaIBQAAIAAAkIhQAAIAAAaIBZAAIAAAog");
	this.shape_26.setTransform(93.5,36.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AhGBUIAAinIBHAAQAgAAATAQQATAPAAAcIAAABQAAAbgUARQgUAPgfAAIgXAAIAAAwgAgXAAIAWAAQALAAAHgFQAIgHAAgJIAAgBQAAgWgaAAIgWAAg");
	this.shape_27.setTransform(78.1,36.8);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AhGBUIAAinIBHAAQAgAAATAQQATAPAAAcIAAABQAAAbgUARQgUAPgfAAIgXAAIAAAwgAgXAAIAWAAQALAAAHgFQAIgHAAgJIAAgBQAAgWgaAAIgWAAg");
	this.shape_28.setTransform(62.5,36.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AhAA+QgagZABglIAAAAQAAgkAagZQAagZAlAAQAmAAAaAZQAbAZgBAkIAAAAQABAlgbAYQgaAagmAAQgmABgagagAgfgfQgLANAAASIAAAAQAAASAMAOQAMANASAAQATAAAMgNQAMgNAAgTIAAAAQAAgSgNgNQgMgOgSAAQgTAAgMAOg");
	this.shape_29.setTransform(44.5,36.8);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AhPBUIAAinIBBAAQArAAAaAYQAZAWAAAlIAAAAQAAAlgZAXQgbAYgrAAgAggArIATAAQAUAAANgLQAMgMAAgUIAAAAQAAgTgMgLQgNgMgUAAIgTAAg");
	this.shape_30.setTransform(26.1,36.8);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgFBUIAAibIg7AAIAAgMICBAAIAAAMIg7AAIAACbg");
	this.shape_31.setTransform(233.2,12.8);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("Ag9A7IAJgJQAbAZAgAAQATAAALgJQAMgKAAgOIAAgBQAAgOgJgHQgLgJgbgGQgdgFgOgLQgNgKAAgUIAAAAQAAgTAPgMQAQgNAXgBQAfAAAaAVIgIAKQgWgTgbAAQgSAAgMAJQgLAJAAAOIAAAAQAAAOAJAIQALAJAcAGQAdAFANALQANAKAAATIAAAAQAAAVgQANQgPAMgZAAQgkAAgfgbg");
	this.shape_32.setTransform(218.2,12.8);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AA2BUIAAhPIhrAAIAABPIgMAAIAAinIAMAAIAABOIBrAAIAAhOIAMAAIAACng");
	this.shape_33.setTransform(202,12.8);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgyA+QgYgZAAgkIAAgBQAAgjAYgZQAYgaAjAAQAVAAAQAIQAOAFAOAOIgJAJQgZgZgfAAQgeABgUAVQgUAWAAAfIAAAAQAAAgAUAWQAVAWAdgBQAfAAAbgaIAIAIQgeAeglAAQgiAAgYgZg");
	this.shape_34.setTransform(185,12.8);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("ABHBmIgWgvIhiAAIgVAvIgNAAIBOioIALAAIBOCogAAsAsIgshgIgsBgIBYAAgAAMhTIAAgSIASAAIAAASgAgdhTIAAgSIASAAIAAASg");
	this.shape_35.setTransform(166.7,11);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AAxBVIgxiRIgwCRIgKAAIg9ioIAOAAIA1CUIAxiVIAIAAIAxCVIA1iUIANAAIg9Cog");
	this.shape_36.setTransform(144.6,12.8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("Ag9A7IAJgJQAbAZAgAAQATAAALgJQAMgKAAgOIAAgBQAAgOgJgHQgLgJgbgGQgdgFgOgLQgNgKAAgUIAAAAQAAgTAPgMQAQgNAXgBQAfAAAaAVIgIAKQgWgTgbAAQgSAAgMAJQgLAJAAAOIAAAAQAAAOAJAIQALAJAcAGQAdAFANALQANAKAAATIAAAAQAAAVgQANQgPAMgZAAQgkAAgfgbg");
	this.shape_37.setTransform(117.4,12.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("ABHBVIgWgwIhiAAIgVAwIgNAAIBOioIALAAIBOCogAAsAaIgshgIgsBgIBYAAg");
	this.shape_38.setTransform(100.8,12.8);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AAxBVIgxiRIgwCRIgKAAIg9ioIAOAAIA1CUIAxiVIAIAAIAxCVIA1iUIANAAIg9Cog");
	this.shape_39.setTransform(78.7,12.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txt1, new cjs.Rectangle(0,0,306,76), null);


(lib.nod_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.nod();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.nod_1, new cjs.Rectangle(0,0,29,29), null);


(lib.mcGlow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.cta_glow();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.1,1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.mcGlow, new cjs.Rectangle(0,0,110,35), null);


(lib.mc_logo2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AkWA8IgIgKQgLAFgOAAQgYABgQgQQgRgRAAgXQAAgaARgQQAPgQAZAAQAYAAAQAPQAQARAAAYIAAABQAAANgFAMQgFALgKAHIAPASgAk4gtQgRAAgMANQgLAMAAATQAAASAMANQAMAMARAAQAJgBAGgCIgOgRIASAAIAIAKQAGgHAEgIQAEgIAAgKQAAgTgNgNQgLgMgQAAIgCAAgAijArQgOgMAAgVIAAhBIAQAAIAABAQAAAOAIAKQAIAHANABQAOgBAJgHQAJgKAAgOIAAhAIAPAAIAABBQAAATgKAMQgMANgZAAQgSAAgNgLgAH4A0IgrgvIgrAvIgUAAIA1g5IgqgyIATAAIAjAnIAjgnIATAAIgsAyIA0A5gAE0A0IAAhrIAPAAIAABrgADHA0IhLhUIAABUIgQAAIAAhrIAPAAIBMBTIAAhTIAPAAIAABrgAAAA0IAAhrIAQAAIAABrgAoMA0IAAhrIBdAAIAAAPIhNAAIAAAeIA0AAIAAANIg0AAIAAAjIBQAAIAAAOg");
	this.shape.setTransform(52.5,44.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CC3E2C").s().p("AgZhqIgPgFIgOAFIAAD5IhXgfIAAi7IgeALIAACmIhXgeIAAiKIAdgJIAAB+IAeALIAAiTIBWgeIAADPIAeAJIAAjjIArgQIArAQIAADjIAdgJIAAjPIBXAeIAACTIAdgLIAAh+IAeAJIAACKIhYAeIAAimIgdgLIAAC7IhWAfgADWA2QgHgHAAgLQAAgMAHgGQAIgJAKAAQAMAAAHAJQAIAGAAAMQAAALgIAHQgHAJgMAAQgKAAgIgJgADYATQgHAIAAAJQAAAKAHAHQAHAGAJAAQAKAAAIgGQAGgIAAgJQAAgJgGgIQgHgGgLgBQgJAAgHAHgADvAxIgHgJIgEAAIAAAJIgGAAIAAgcIANAAQAFABADACQADACAAAEQAAAHgGACIAGAKgADkAkIAGAAQAFgBAAgEQAAgEgFAAIgGAAg");
	this.shape_1.setTransform(57.4,14.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_logo2, new cjs.Rectangle(0,0,105,50.8), null);


(lib.mc_logo1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC3E2C").s().p("AgPhAIgJgDIgJADIAACXIg1gTIAAhxIgSAGIAABmIg1gTIAAhUIASgGIAABNIASAHIAAhZIA1gTIAAB+IASAGIAAiLIAagJIAaAJIAACLIARgGIAAh+IA2ATIAABZIARgHIAAhNIASAGIAABUIg1ATIAAhmIgSgGIAABxIg0ATgACDAhQgFgFAAgGQAAgHAFgEQAEgGAHAAQAHAAAEAGQAFAEAAAHQAAAGgFAFQgEAFgHAAQgHAAgEgFgACEAMQgEAEAAAGQAAAGAEAEQAEAEAGAAQAGAAAEgEQAEgFAAgFQAAgGgEgEQgEgEgGgBQgGAAgEAFgACSAeIgEgGIgDAAIAAAGIgEAAIAAgRIAIAAQADAAACABQABABAAAAQAAABAAAAQABABAAAAQAAABAAABQAAAEgEABIAEAGgACLAWIAEAAQAAgBABAAQABAAAAAAQAAAAABgBQAAAAAAgBQAAgBAAAAQgBgBAAAAQAAAAgBAAQgBgBAAAAIgEAAg");
	this.shape.setTransform(35,8.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#020202").s().p("AipAkIgFgGQgHAEgIAAQgPAAgKgKQgKgKAAgOQAAgPAKgKQAJgKAQAAQAOAAAKAJQAKAKAAAPIAAABQAAAHgEAHQgCAHgHAFIAKAKgAi+gbQgKAAgHAIQgIAHAAAMQABAKAHAIQAHAIALgBQAFAAAEgBIgJgLIALAAIAFAGQAEgEACgEQADgFAAgGQAAgMgIgIQgHgHgKAAIgBAAgAhjAaQgIgHgBgNIAAgnIAKAAIAAAnQAAAIAFAGQAFAFAIAAQAIAAAGgFQAGgGgBgIIAAgnIAJAAIAAAnQAAALgFAIQgIAIgPAAQgLAAgIgHgAEzAgIgagdIgbAdIgLAAIAggjIgageIAMAAIAVAYIAWgYIALAAIgbAeIAgAjgAC8AgIAAhBIAJAAIAABBgAB6AgIgvgzIAAAzIgJAAIAAhBIAJAAIAvAyIAAgyIAJAAIAABBgAAAAgIAAhBIAJAAIAABBgAk/AgIAAhBIA5AAIAAAJIgvAAIAAASIAfAAIAAAIIgfAAIAAAVIAwAAIAAAJg");
	this.shape_1.setTransform(32,27.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_logo1, new cjs.Rectangle(0,0,64,31), null);


(lib.mc_blackBox = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc_blackBox, new cjs.Rectangle(0,0,300,250), null);


(lib.imgGreyBase = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.img35Grey();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.imgGreyBase, new cjs.Rectangle(0,0,300,250), null);


(lib._img = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.img35_85p();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._img, new cjs.Rectangle(0,0,439,303), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AASAqIgTgdIgBAAIgSAAIAAAdIgOAAIAAhTIAjAAQAJAAAGACQAGACAEAEQADAEACAEQACAFAAAFIAAABQAAAFgCAEIgDAGIgHAGIgIADIAXAggAgUAAIAVAAQAHAAAFgDQAFgEAAgGQAAgIgFgDQgEgDgIgBIgVAAg");
	this.shape.setTransform(143,14.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAUAqIAAgjIgnAAIAAAjIgPAAIAAhTIAPAAIAAAjIAnAAIAAgjIAPAAIAABTg");
	this.shape_1.setTransform(134.3,14.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgeAqIAAhTIA9AAIAAANIgvAAIAAAWIApAAIAAANIgpAAIAAAVIAvAAIAAAOg");
	this.shape_2.setTransform(126.4,14.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAaAqIAAg7IgaAnIAAAAIgagnIAAA7IgOAAIAAhTIAPAAIAZAoIAZgoIAQAAIAABTg");
	this.shape_3.setTransform(117.5,14.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgeAqIAAhTIA9AAIAAANIgvAAIAAAWIApAAIAAANIgpAAIAAAVIAvAAIAAAOg");
	this.shape_4.setTransform(105.9,14.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgHAqIAAhTIAPAAIAABTg");
	this.shape_5.setTransform(100.3,14.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgPAoQgJgEgHgGIAIgLQAHAFAGADQAGADAHAAQAHAAAEgDQAEgDAAgFIgBgDIgDgEIgGgDIgIgCIgMgEQgFgCgEgCQgEgCgBgFQgCgEAAgGIAAAAQAAgGACgEIAGgIIAJgEQAFgCAGAAQAJAAAHADQAHACAHAGIgIALQgGgFgGgCQgFgCgFAAQgGAAgEACQgEADAAAFIABAEIADAEIAGACIAJADIAMAEQAFACAEACIAFAHQABADAAAGQAAAGgCAEQgCAGgEACQgEAEgFACQgGABgGAAQgJAAgJgDg");
	this.shape_6.setTransform(95,14.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAYAqIgtg7IAAA7IgPAAIAAhTIAOAAIAsA5IAAg5IAOAAIAABTg");
	this.shape_7.setTransform(84,14.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgeAqIAAhTIA9AAIAAANIgvAAIAAAWIApAAIAAANIgpAAIAAAVIAvAAIAAAOg");
	this.shape_8.setTransform(75.9,14.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AASAqIgUgdIAAAAIgSAAIAAAdIgPAAIAAhTIAkAAQAIAAAHACQAGACAEAEQADAEACAEQACAFAAAFIAAABQAAAFgBAEIgFAGIgGAGIgIADIAWAggAgUAAIAUAAQAIAAAGgDQAEgEAAgGQAAgIgEgDQgFgDgJgBIgUAAg");
	this.shape_9.setTransform(68.2,14.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAUAqIAAgjIgnAAIAAAjIgPAAIAAhTIAPAAIAAAjIAnAAIAAgjIAPAAIAABTg");
	this.shape_10.setTransform(59.5,14.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAcAqIgIgUIgnAAIgJAUIgPAAIAlhTIANAAIAlBTgAAOAJIgOghIgNAhIAbAAg");
	this.shape_11.setTransform(50.7,14.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgeAqIAAhTIA9AAIAAANIguAAIAAAYIApAAIAAAMIgpAAIAAAig");
	this.shape_12.setTransform(42.9,14.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AASAqIgTgdIgBAAIgSAAIAAAdIgPAAIAAhTIAkAAQAJAAAGACQAGACAEAEQAEAEABAEQACAFAAAFIAAABQAAAFgBAEIgFAGIgGAGIgIADIAXAggAgUAAIAUAAQAJAAAFgDQAEgEAAgGQAAgIgEgDQgFgDgJgBIgUAAg");
	this.shape_13.setTransform(35.2,14.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgeAqIAAhTIA9AAIAAANIgvAAIAAAWIApAAIAAANIgpAAIAAAVIAvAAIAAAOg");
	this.shape_14.setTransform(27.2,14.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_1
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#ED1C24").s().p("AqdCTIigklIZ7AAIAAElg");
	this.shape_15.setTransform(83,14.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(0,0,166,29.4), null);


(lib.boxWhite = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bDrIAAnVMAu3AAAIAAHVg");
	this.shape.setTransform(150,23.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.boxWhite, new cjs.Rectangle(0,0,300,47), null);


(lib.beam2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.beam2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.beam2_1, new cjs.Rectangle(0,0,109,42), null);


(lib.beam1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.beam1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.beam1_1, new cjs.Rectangle(0,0,191,162), null);


(lib.bigBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0066CC").s().p("A3bXcMAAAgu3MAu3AAAMAAAAu3g");
	this.shape.setTransform(150,150);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.img_grey = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{over:4,out:13});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_10 = function() {
		this.stop();
	}
	this.frame_19 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(10).call(this.frame_10).wait(9).call(this.frame_19).wait(1));

	// Layer_1
	this.instance = new lib.imgGreyBase();
	this.instance.parent = this;
	this.instance.setTransform(150,101.5,1,1,0,0,0,150,101.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({alpha:0},6).wait(3).to({alpha:1},6).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.ctaEnd = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"over":4});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_12 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(12).call(this.frame_12).wait(8));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AASAqIgTgdIgBAAIgSAAIAAAdIgPAAIAAhTIAkAAQAJAAAGACQAGACAEAEQAEAEABAEQACAFAAAFIAAABQAAAFgBAEIgFAGIgGAGIgIADIAWAggAgUAAIAUAAQAIAAAGgDQAEgEAAgGQAAgIgEgDQgFgDgJgBIgUAAg");
	this.shape.setTransform(137,14.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAUAqIAAgjIgnAAIAAAjIgPAAIAAhTIAPAAIAAAjIAnAAIAAgjIAPAAIAABTg");
	this.shape_1.setTransform(128.3,14.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgeAqIAAhTIA9AAIAAANIgvAAIAAAWIApAAIAAANIgpAAIAAAVIAvAAIAAAOg");
	this.shape_2.setTransform(120.4,14.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAaAqIAAg7IgaAnIAAAAIgagnIAAA7IgOAAIAAhTIAPAAIAZAoIAZgoIAQAAIAABTg");
	this.shape_3.setTransform(111.5,14.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgeAqIAAhTIA9AAIAAANIgvAAIAAAWIApAAIAAANIgpAAIAAAVIAvAAIAAAOg");
	this.shape_4.setTransform(99.9,14.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgHAqIAAhTIAOAAIAABTg");
	this.shape_5.setTransform(94.3,14.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgPAoQgJgEgHgGIAIgLQAHAFAGADQAGADAHAAQAHAAAEgDQAEgDAAgFIgBgDIgDgEIgGgDIgIgCIgMgEQgFgCgEgCQgEgCgBgFQgCgEAAgGIAAAAQAAgGACgEIAGgIIAJgEQAFgCAGAAQAJAAAHADQAHACAHAGIgIALQgGgFgGgCQgFgCgFAAQgGAAgEACQgEADAAAFIABAEIADAEIAGACIAJADIAMAEQAFACAEACIAFAHQABADAAAGQAAAGgCAEQgCAGgEACQgEAEgFACQgGABgGAAQgJAAgJgDg");
	this.shape_6.setTransform(89,14.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAYAqIgtg7IAAA7IgOAAIAAhTIANAAIAsA5IAAg5IAPAAIAABTg");
	this.shape_7.setTransform(78,14.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgeAqIAAhTIA9AAIAAANIgvAAIAAAWIApAAIAAANIgpAAIAAAVIAvAAIAAAOg");
	this.shape_8.setTransform(69.9,14.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AASAqIgUgdIAAAAIgSAAIAAAdIgOAAIAAhTIAkAAQAHAAAHACQAGACAEAEQADAEACAEQACAFAAAFIAAABQAAAFgCAEIgDAGIgHAGIgIADIAXAggAgUAAIAVAAQAHAAAFgDQAFgEAAgGQAAgIgFgDQgEgDgIgBIgVAAg");
	this.shape_9.setTransform(62.2,14.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAUAqIAAgjIgnAAIAAAjIgPAAIAAhTIAPAAIAAAjIAnAAIAAgjIAPAAIAABTg");
	this.shape_10.setTransform(53.5,14.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAcAqIgIgUIgnAAIgJAUIgPAAIAlhTIANAAIAlBTgAAOAJIgOghIgNAhIAbAAg");
	this.shape_11.setTransform(44.7,14.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgeAqIAAhTIA9AAIAAANIgvAAIAAAYIAqAAIAAAMIgqAAIAAAig");
	this.shape_12.setTransform(36.9,14.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AASAqIgUgdIAAAAIgSAAIAAAdIgPAAIAAhTIAlAAQAHAAAHACQAGACAEAEQADAEACAEQACAFAAAFIAAABQAAAFgBAEIgFAGIgGAGIgIADIAWAggAgUAAIAUAAQAJAAAFgDQAEgEAAgGQAAgIgEgDQgFgDgJgBIgUAAg");
	this.shape_13.setTransform(29.2,14.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgeAqIAAhTIA9AAIAAANIgvAAIAAAWIApAAIAAANIgpAAIAAAVIAvAAIAAAOg");
	this.shape_14.setTransform(21.2,14.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(20));

	// Layer_5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AsVCWIAAkrIYrAAIAAErg");
	mask.setTransform(79,15);

	// Layer_4
	this.instance = new lib.mcGlow();
	this.instance.parent = this;
	this.instance.setTransform(-58,15.5,1,1,0,0,0,50,17.5);
	this.instance.alpha = 0.699;
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({_off:false},0).to({x:211},8).wait(8));

	// Layer_1
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#ED1C24").s().p("AsVCWIAAkrIYrAAIAAErg");
	this.shape_15.setTransform(79,15);

	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(20));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,158,30);


(lib.animeBeam = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_18
	this.instance = new lib.nod_1();
	this.instance.parent = this;
	this.instance.setTransform(-84.5,92.2,0.51,0.51,0,0,0,14.4,14.7);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(43).to({_off:false},0).wait(44));

	// Layer_19
	this.instance_1 = new lib.nod_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(103.1,89.1,0.8,0.8,0,0,0,14.6,14.7);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(39).to({_off:false},0).wait(48));

	// Layer_17
	this.instance_2 = new lib.nod_1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(8.2,87.7,0.7,0.7,0,0,0,14.5,14.7);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(34).to({_off:false},0).wait(53));

	// Layer_3
	this.instance_3 = new lib.nod_1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(52.1,89.7,0.7,0.7,0,0,0,14.5,14.7);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(27).to({_off:false},0).wait(60));

	// Layer_4
	this.instance_4 = new lib.nod_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-34.4,113.5,0.6,0.6,0,0,0,14.4,14.6);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(25).to({_off:false},0).wait(62));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AoWTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_1 = new cjs.Graphics().p("AqSTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_2 = new cjs.Graphics().p("AsGTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_3 = new cjs.Graphics().p("AtyTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_4 = new cjs.Graphics().p("AvWTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_5 = new cjs.Graphics().p("AwzTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_6 = new cjs.Graphics().p("AyHTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_7 = new cjs.Graphics().p("AzTTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_8 = new cjs.Graphics().p("A0XTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_9 = new cjs.Graphics().p("A1TTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_10 = new cjs.Graphics().p("A2HTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_11 = new cjs.Graphics().p("A2zTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_12 = new cjs.Graphics().p("A3XTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_13 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_14 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_15 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_16 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:246.5,y:114.6}).wait(1).to({graphics:mask_graphics_1,x:234.1,y:114.6}).wait(1).to({graphics:mask_graphics_2,x:222.5,y:114.6}).wait(1).to({graphics:mask_graphics_3,x:211.7,y:114.6}).wait(1).to({graphics:mask_graphics_4,x:201.7,y:114.6}).wait(1).to({graphics:mask_graphics_5,x:192.4,y:114.6}).wait(1).to({graphics:mask_graphics_6,x:184,y:114.6}).wait(1).to({graphics:mask_graphics_7,x:176.4,y:114.6}).wait(1).to({graphics:mask_graphics_8,x:169.6,y:114.6}).wait(1).to({graphics:mask_graphics_9,x:163.6,y:114.6}).wait(1).to({graphics:mask_graphics_10,x:158.4,y:114.6}).wait(1).to({graphics:mask_graphics_11,x:154,y:114.6}).wait(1).to({graphics:mask_graphics_12,x:150.4,y:114.6}).wait(1).to({graphics:mask_graphics_13,x:145.2,y:114.6}).wait(1).to({graphics:mask_graphics_14,x:141.2,y:114.6}).wait(1).to({graphics:mask_graphics_15,x:138.8,y:114.6}).wait(1).to({graphics:mask_graphics_16,x:138,y:114.6}).wait(71));

	// Layer_1
	this.instance_5 = new lib.beam1_1();
	this.instance_5.parent = this;
	this.instance_5.setTransform(95.5,81,1,1,0,0,0,95.5,81);

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(87));

	// Layer_7
	this.instance_6 = new lib.beam2_1();
	this.instance_6.parent = this;
	this.instance_6.setTransform(100.3,89.3,0.074,0.093,7.8,0,0,54.1,22.4);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(53).to({_off:false},0).to({regX:54.4,scaleX:1.18,scaleY:0.55,x:148.8,y:97.3},9).wait(25));

	// Layer_6
	this.instance_7 = new lib.beam2_1();
	this.instance_7.parent = this;
	this.instance_7.setTransform(52.7,88.7,0.076,0.089,-0.2,0,0,54.6,22.1);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(46).to({_off:false},0).to({regX:54.1,regY:22,scaleX:0.62,scaleY:0.37,x:79.6,y:89.7},8).wait(33));

	// Layer_16
	this.instance_8 = new lib.beam2_1();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-83.6,93.5,0.045,0.143,-167.4,0,0,54.6,20.9);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(50).to({_off:false},0).to({regX:54,regY:21.2,scaleX:0.35,scaleY:0.4,x:-102.6,y:87},8).wait(29));

	// Layer_15
	this.instance_9 = new lib.beam2_1();
	this.instance_9.parent = this;
	this.instance_9.setTransform(7,89.4,0.08,0.25,177.6,0,0,54.2,21.6);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(40).to({_off:false},0).to({regX:54,scaleX:1.14,scaleY:0.37,x:-46.6,y:90.5},10).wait(37));

	// Layer_11
	this.instance_10 = new lib.beam2_1();
	this.instance_10.parent = this;
	this.instance_10.setTransform(9,88.7,0.042,0.118,-2.4,0,0,54.2,22.6);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(34).to({_off:false},0).to({regX:54.1,regY:21.9,scaleX:0.62,scaleY:0.37,x:32.6,y:89.2},8).wait(45));

	// Layer_14
	this.instance_11 = new lib.beam2_1();
	this.instance_11.parent = this;
	this.instance_11.setTransform(-36.5,114,0.06,0.095,-158.2,0,0,54.9,21.4);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(35).to({_off:false},0).to({regX:54.4,regY:21.6,scaleX:0.67,scaleY:0.37,x:-63.5,y:101.1},8).wait(44));

	// Layer_13
	this.instance_12 = new lib.beam2_1();
	this.instance_12.parent = this;
	this.instance_12.setTransform(27.4,131.3,0.051,0.119,-30.5,0,0,54.2,21.1);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(29).to({_off:false},0).to({regX:54.5,regY:21.8,scaleX:1.08,scaleY:0.57,x:67.6,y:110.9},10).wait(48));

	// Layer_10
	this.instance_13 = new lib.beam2_1();
	this.instance_13.parent = this;
	this.instance_13.setTransform(-36.3,114.2,0.061,0.174,-30.5,0,0,53.5,21.6);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(25).to({_off:false},0).to({regX:54.4,regY:21.4,scaleX:0.64,scaleY:0.65,x:-8.8,y:100.2},9).wait(53));

	// Layer_8
	this.instance_14 = new lib.beam2_1();
	this.instance_14.parent = this;
	this.instance_14.setTransform(24.8,132.1,0.2,0.396,104.5,0,0,54,21.4);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(39).to({_off:false},0).to({regX:54.1,scaleX:1.15,scaleY:0.95,x:12.8,y:181},9).wait(39));

	// Layer_12
	this.instance_15 = new lib.beam2_1();
	this.instance_15.parent = this;
	this.instance_15.setTransform(29.3,129.9,0.088,0.193,-60.5,0,0,53.9,21.5);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(18).to({_off:false},0).to({regX:54.3,scaleX:0.67,scaleY:0.65,x:40.9,y:110.7},9).wait(60));

	// Layer_5
	this.instance_16 = new lib.beam2_1();
	this.instance_16.parent = this;
	this.instance_16.setTransform(23.6,135.1,0.102,0.354,14.5,0,0,54.9,21.4);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(16).to({_off:false},0).to({regX:54.6,scaleX:0.89,scaleY:0.91,x:-1.3,y:125.6},9).wait(62));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


// stage content:
(lib.equinix_banner_German_300x250 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		// Enable mouse interaction with the stage 
		stage.enableMouseOver();
		
		var root = this;
		var bigBtn = root.bigBtn;
		
		// Add event listeners - Add it to the CANVAS for iFrame compatibility
		canvas.addEventListener("mouseover", over.bind(this));  
		//canvas.addEventListener("mouseout", out.bind(this)); 
		bigBtn.addEventListener("click", click.bind(this)); 
		
		function over()  
		{  
		  this.ctaEnd.gotoAndPlay("over");
		}  
		  
		//function out()  
		//{  
		//  this.grey.gotoAndPlay("out"); 
		//} 
		
		function click()  
		{  
		  window.parent.postMessage("click","*");
		  window.open(window.clickTag);
		}
	}
	this.frame_448 = function() {
		this.ctaEnd.gotoAndPlay("over");
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(448).call(this.frame_448).wait(1));

	// bigBtn
	this.bigBtn = new lib.bigBtn();
	this.bigBtn.name = "bigBtn";
	this.bigBtn.parent = this;
	this.bigBtn.setTransform(150,104.2,1,0.833,0,0,0,150,125);
	new cjs.ButtonHelper(this.bigBtn, 0, 1, 2, false, new lib.bigBtn(), 3);

	this.timeline.addTween(cjs.Tween.get(this.bigBtn).wait(449));

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,0,0,3).p("A3WzcMAutAAAMAAAAm5MgutAAAg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	// ctaEnd
	this.ctaEnd = new lib.ctaEnd();
	this.ctaEnd.name = "ctaEnd";
	this.ctaEnd.parent = this;
	this.ctaEnd.setTransform(150.1,272,1,1,0,0,0,79,15);

	this.timeline.addTween(cjs.Tween.get(this.ctaEnd).wait(425).to({y:209,alpha:0},0).to({alpha:1},11).wait(13));

	// logo2
	this.instance = new lib.mc_logo2();
	this.instance.parent = this;
	this.instance.setTransform(150.1,47.6,1,1,0,0,0,52.5,25.4);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(425).to({_off:false},0).to({alpha:1},11).wait(13));

	// txt5
	this.instance_1 = new lib.txtEnd();
	this.instance_1.parent = this;
	this.instance_1.setTransform(149.5,134.5,1,1,0,0,0,153.5,50.5);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(425).to({_off:false},0).to({alpha:1},11).wait(13));

	// txt4
	this.instance_2 = new lib.txt4();
	this.instance_2.parent = this;
	this.instance_2.setTransform(150,50,1,1,0,0,0,153,14);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(259).to({_off:false},0).to({alpha:1},9).wait(38).to({alpha:0},9).to({_off:true},1).wait(133));

	// txt3
	this.instance_3 = new lib.txt3();
	this.instance_3.parent = this;
	this.instance_3.setTransform(150,50,1,1,0,0,0,153,38);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(166).to({_off:false},0).to({alpha:1},9).wait(70).to({alpha:0},9).to({_off:true},1).wait(194));

	// txt2
	this.instance_4 = new lib.txt2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(148,50,1,1,0,0,0,153,14);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(107).to({_off:false},0).to({alpha:1},10).wait(35).to({alpha:0},9).to({_off:true},1).wait(287));

	// txt1
	this.instance_5 = new lib.txt1();
	this.instance_5.parent = this;
	this.instance_5.setTransform(150,50,1,1,0,0,0,153,38);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(18).to({_off:false},0).to({alpha:1},10).wait(63).to({alpha:0},11).to({_off:true},1).wait(346));

	// darker
	this.instance_6 = new lib.mc_blackBox();
	this.instance_6.parent = this;
	this.instance_6.setTransform(150,125,1,1,0,0,0,150,125);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(407).to({_off:false},0).to({alpha:0.648},14).wait(28));

	// cta
	this.cta = new lib.cta();
	this.cta.name = "cta";
	this.cta.parent = this;
	this.cta.setTransform(218,227.7,1,1,0,0,0,83,14.7);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(407).to({alpha:0},14).to({_off:true},1).wait(27));

	// logo
	this.instance_7 = new lib.mc_logo1();
	this.instance_7.parent = this;
	this.instance_7.setTransform(47,226.4,1,1,0,0,0,32,15.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(407).to({alpha:0},14).to({_off:true},1).wait(27));

	// whiteBar
	this.instance_8 = new lib.boxWhite();
	this.instance_8.parent = this;
	this.instance_8.setTransform(150,226.5,1,1,0,0,0,150,23.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(407).to({alpha:0},14).to({_off:true},1).wait(27));

	// shade
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(0,0,0,0)","rgba(0,0,0,0.698)"],[0,0.957],-0.1,0,0,-0.1,0,177).s().p("EgnDAXbMAAAgu2MBOHAAAMAAAAu2g");
	this.shape_1.setTransform(150,150);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["rgba(0,0,0,0)","rgba(0,0,0,0.647)"],[0,0.957],-0.1,0,0,-0.1,0,177).s().p("EgnDAXbMAAAgu2MBOHAAAMAAAAu2g");
	this.shape_2.setTransform(150,150);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0)","rgba(0,0,0,0.6)"],[0,0.957],-0.1,0,0,-0.1,0,177).s().p("EgnDAXbMAAAgu2MBOHAAAMAAAAu2g");
	this.shape_3.setTransform(150,150);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["rgba(0,0,0,0)","rgba(0,0,0,0.549)"],[0,0.957],-0.1,0,0,-0.1,0,177).s().p("EgnDAXbMAAAgu2MBOHAAAMAAAAu2g");
	this.shape_4.setTransform(150,150);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0)","rgba(0,0,0,0.498)"],[0,0.957],-0.1,0,0,-0.1,0,177).s().p("EgnDAXbMAAAgu2MBOHAAAMAAAAu2g");
	this.shape_5.setTransform(150,150);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.rf(["rgba(0,0,0,0)","rgba(0,0,0,0.447)"],[0,0.957],-0.1,0,0,-0.1,0,177).s().p("EgnDAXbMAAAgu2MBOHAAAMAAAAu2g");
	this.shape_6.setTransform(150,150);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0)","rgba(0,0,0,0.4)"],[0,0.957],-0.1,0,0,-0.1,0,177).s().p("EgnDAXbMAAAgu2MBOHAAAMAAAAu2g");
	this.shape_7.setTransform(150,150);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.rf(["rgba(0,0,0,0)","rgba(0,0,0,0.349)"],[0,0.957],-0.1,0,0,-0.1,0,177).s().p("EgnDAXbMAAAgu2MBOHAAAMAAAAu2g");
	this.shape_8.setTransform(150,150);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.rf(["rgba(0,0,0,0)","rgba(0,0,0,0.298)"],[0,0.957],-0.1,0,0,-0.1,0,177).s().p("EgnDAXbMAAAgu2MBOHAAAMAAAAu2g");
	this.shape_9.setTransform(150,150);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.rf(["rgba(0,0,0,0)","rgba(0,0,0,0.251)"],[0,0.957],-0.1,0,0,-0.1,0,177).s().p("EgnDAXbMAAAgu2MBOHAAAMAAAAu2g");
	this.shape_10.setTransform(150,150);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.rf(["rgba(0,0,0,0)","rgba(0,0,0,0.2)"],[0,0.957],-0.1,0,0,-0.1,0,177).s().p("EgnDAXbMAAAgu2MBOHAAAMAAAAu2g");
	this.shape_11.setTransform(150,150);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.rf(["rgba(0,0,0,0)","rgba(0,0,0,0.149)"],[0,0.957],-0.1,0,0,-0.1,0,177).s().p("EgnDAXbMAAAgu2MBOHAAAMAAAAu2g");
	this.shape_12.setTransform(150,150);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.rf(["rgba(0,0,0,0)","rgba(0,0,0,0.098)"],[0,0.957],-0.1,0,0,-0.1,0,177).s().p("EgnDAXbMAAAgu2MBOHAAAMAAAAu2g");
	this.shape_13.setTransform(150,150);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.rf(["rgba(0,0,0,0)","rgba(0,0,0,0.051)"],[0,0.957],-0.1,0,0,-0.1,0,177).s().p("EgnDAXbMAAAgu2MBOHAAAMAAAAu2g");
	this.shape_14.setTransform(150,150);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.rf(["rgba(0,0,0,0)","rgba(0,0,0,0)"],[0,0.957],-0.1,0,0,-0.1,0,177).s().p("EgnDAXbMAAAgu2MBOHAAAMAAAAu2g");
	this.shape_15.setTransform(150,150);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).to({state:[{t:this.shape_1}]},311).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[]},1).wait(123));

	// img_grey
	this.instance_9 = new lib.img_grey();
	this.instance_9.parent = this;
	this.instance_9.setTransform(150,101.5,1,1,0,0,0,150,101.5);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.grey = new lib.img_grey();
	this.grey.name = "grey";
	this.grey.parent = this;
	this.grey.setTransform(150,101.5,1,1,0,0,0,150,101.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_9}]},407).to({state:[{t:this.grey}]},14).wait(28));
	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(407).to({_off:false},0).to({_off:true,alpha:1},14).wait(28));

	// anime_beams
	this.instance_10 = new lib.animeBeam("synched",0,false);
	this.instance_10.parent = this;
	this.instance_10.setTransform(248.5,82.5,1,1,0,0,0,139.5,82.5);
	this.instance_10.alpha = 0.602;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(330).to({_off:false},0).wait(119));

	// img
	this.instance_11 = new lib._img();
	this.instance_11.parent = this;
	this.instance_11.setTransform(192,97.1,1.18,1.18,0,0,0,257.9,178.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).to({regX:257.8,regY:178.3,scaleX:0.69,scaleY:0.69,x:176.6,y:121.4},316).wait(133));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(37.7,11.6,518,413.3);
// library properties:
lib.properties = {
	id: '368DAC635862472CB1A82E34F0B0D03B',
	width: 300,
	height: 250,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/beam1.png?1513050402261", id:"beam1"},
		{src:"images/beam2.png?1513050402261", id:"beam2"},
		{src:"images/cta_glow.png?1513050402261", id:"cta_glow"},
		{src:"images/img35_85p.jpg?1513050402261", id:"img35_85p"},
		{src:"images/img35Grey.jpg?1513050402261", id:"img35Grey"},
		{src:"images/nod.png?1513050402261", id:"nod"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['368DAC635862472CB1A82E34F0B0D03B'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;